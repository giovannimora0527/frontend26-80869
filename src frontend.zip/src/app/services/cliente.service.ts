import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BackendService } from 'src/app/services/backend.service';
import { environment } from 'src/environments/environment';

/**
 * Servicio para gestionar las operaciones de clientes.
 */
@Injectable({
  providedIn: 'root'
})
export class ClienteService {

  private api = 'cliente';

  constructor(private backendService: BackendService) { }

  /**
   * Lista todos los clientes registrados.
   * @returns Observable con el array de clientes
   */
  listarClientes(): Observable<any[]> {
    return this.backendService.get(environment.apiUrlAuth, this.api, 'listar');
  }

  /**
   * Consulta un cliente por su ID.
   * @param id Identificador del cliente
   * @returns Observable con los datos del cliente
   */
  consultarCliente(id: number): Observable<any> {
    return this.backendService.get(environment.apiUrlAuth, this.api, `consultar/${id}`);
  }
}