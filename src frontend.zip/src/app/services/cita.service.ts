import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BackendService } from './backend.service';
import { environment } from '../../environments/environment';

/**
 * Interfaz que representa una cita médica en el frontend.
 */
export interface Cita {
  id: number;
  fechaHora: string;
  motivo: string;
  estado: string;
  cliente: {
    id: number;
    nombres: string;
    apellidos: string;
  };
  mascota: {
    mascotaId: number;
    nombreMascota: string;
  };
  medico: {
    id: number;
    nombres: string;
    apellidos: string;
  };
  fechaCreacion: string;
  fechaModificacion?: string;
}

/**
 * Interfaz para el request de creación/edición de citas.
 */
export interface CitaRq {
  id?: number;
  clienteId: number;
  mascotaId: number;
  medicoId: number;
  fecha: string;
  hora: string;
  motivo: string;
  estado: string;
}

/**
 * Servicio para gestionar las operaciones CRUD de citas médicas.
 */
@Injectable({
  providedIn: 'root'
})
export class CitaService {

  private api = 'cita';

  constructor(private backendService: BackendService) { }

  /**
   * Lista todas las citas ordenadas por fecha descendente.
   */
  getCitas(): Observable<Cita[]> {
    return this.backendService.get<Cita[]>(environment.apiUrlAuth, this.api, 'listar');
  }

  /**
   * Consulta una cita específica por su ID.
   */
  getCitaById(id: number): Observable<Cita> {
    return this.backendService.get<Cita>(environment.apiUrlAuth, this.api, `consultar/${id}`);
  }

  /**
   * Crea una nueva cita médica.
   */
  addCita(cita: CitaRq): Observable<any> {
    return this.backendService.post<any>(environment.apiUrlAuth, this.api, 'guardar', cita);
  }

  /**
   * Actualiza una cita existente.
   */
  updateCita(cita: CitaRq): Observable<any> {
    return this.backendService.post<any>(environment.apiUrlAuth, this.api, 'actualizar', cita);
  }

  /**
   * Elimina o cancela una cita.
   */
  deleteCita(id: number): Observable<any> {
    return this.backendService.delete<any>(environment.apiUrlAuth, this.api, `eliminar/${id}`);
  }
}