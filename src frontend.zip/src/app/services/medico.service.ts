import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BackendService } from 'src/app/services/backend.service';
import { environment } from 'src/environments/environment';

/**
 * Servicio para gestionar las operaciones de veterinarios/médicos.
 */
@Injectable({
  providedIn: 'root'
})
export class MedicoService {

  private api = 'medico';

  constructor(private backendService: BackendService) { }

  /**
   * Lista todos los veterinarios registrados.
   * @returns Observable con el array de médicos
   */
  listarMedicos(): Observable<any[]> {
    return this.backendService.get(environment.apiUrlAuth, this.api, 'listar');
  }

  /**
   * Consulta un veterinario por su ID.
   * @param id Identificador del médico
   * @returns Observable con los datos del médico
   */
  consultarMedico(id: number): Observable<any> {
    return this.backendService.get(environment.apiUrlAuth, this.api, `consultar/${id}`);
  }
}