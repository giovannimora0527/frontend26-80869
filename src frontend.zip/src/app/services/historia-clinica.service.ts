import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BackendService } from 'src/app/services/backend.service';
import { environment } from 'src/environments/environment';

/**
 * Servicio para gestionar historias clínicas y anotaciones.
 */
@Injectable({
  providedIn: 'root'
})
export class HistoriaClinicaService {

  private apiHistoria = 'historia-medica';
  private apiAnotacion = 'anotacion-historia';

  constructor(private backendService: BackendService) { }

  /**
   * Lista todas las historias clínicas.
   * @returns Observable con el array de historias
   */
  listarHistorias(): Observable<any[]> {
    return this.backendService.get(environment.apiUrlAuth, this.apiHistoria, 'listar');
  }

  /**
   * Crea una nueva historia clínica.
   * @param historia Datos de la historia
   * @returns Observable con la respuesta
   */
  crearHistoria(historia: any): Observable<any> {
    return this.backendService.post(environment.apiUrlAuth, this.apiHistoria, 'guardar', historia);
  }

  /**
   * Lista las anotaciones de una historia clínica específica.
   * @param historiaId ID de la historia clínica
   * @returns Observable con las anotaciones
   */
  listarAnotacionesPorHistoria(historiaId: number): Observable<any[]> {
    return this.backendService.get(environment.apiUrlAuth, this.apiAnotacion, `listarPorHistoria/${historiaId}`);
  }

  /**
   * Crea una nueva anotación en una historia clínica.
   * @param anotacion Datos de la anotación
   * @returns Observable con la respuesta
   */
  crearAnotacion(anotacion: any): Observable<any> {
    return this.backendService.post(environment.apiUrlAuth, this.apiAnotacion, 'guardar', anotacion);
  }
}