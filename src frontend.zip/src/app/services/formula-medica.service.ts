import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BackendService } from './backend.service';
import { environment } from '../../environments/environment';

/**
 * Interfaz que representa una fórmula médica en el frontend.
 * Incluye campos de entidades relacionadas para mostrar información resumida.
 */
export interface FormulaMedica {
  id: number;
  cita: {
    id: number;
    fechaHora: string;
    motivo: string;
    estado: string;
    mascota: {
      mascotaId: number;
      nombreMascota: string;
      nombre?: string;
      cliente: {
        id: number;
        nombres: string;
        apellidos: string;
      };
    };
    medico: {
      id: number;
      nombres: string;
      apellidos: string;
    };
  };
  medicamento: {
    id: number;
    nombre: string;
    descripcion?: string;
    presentacion?: string;
  };
  dosis: string;
  indicaciones: string;
  fechaCreacionRegistro: string;
  fechaActualizacionRegistro?: string;
}

/**
 * Servicio para gestionar las operaciones CRUD de fórmulas médicas.
 * Se comunica con el backend a través del BackendService.
 */
@Injectable({
  providedIn: 'root'
})
export class FormulaMedicaService {

  private api = 'formula-medica';

  constructor(private backendService: BackendService) { }

  /**
   * Lista todas las fórmulas médicas ordenadas por fecha de creación descendente.
   * @returns Observable con el array de fórmulas médicas
   */
  getFormulas(): Observable<FormulaMedica[]> {
    return this.backendService.get<FormulaMedica[]>(
      environment.apiUrlAuth, 
      this.api, 
      'listar'
    );
  }

  /**
   * Consulta una fórmula médica específica por su ID.
   * @param id Identificador de la fórmula
   * @returns Observable con los datos completos de la fórmula
   */
  getFormulaById(id: number): Observable<FormulaMedica> {
    return this.backendService.get<FormulaMedica>(
      environment.apiUrlAuth, 
      this.api, 
      `consultar/${id}`
    );
  }

  /**
   * Crea una nueva fórmula médica.
   * @param formula Datos de la fórmula a crear
   * @returns Observable con la fórmula creada
   */
  addFormula(formula: FormulaMedica): Observable<FormulaMedica> {
    return this.backendService.post<FormulaMedica>(
      environment.apiUrlAuth, 
      this.api, 
      'guardar', 
      formula
    );
  }

  /**
   * Actualiza una fórmula médica existente.
   * @param id Identificador de la fórmula
   * @param formula Nuevos datos de la fórmula
   * @returns Observable con la fórmula actualizada
   */
  updateFormula(id: number, formula: FormulaMedica): Observable<FormulaMedica> {
    return this.backendService.put<FormulaMedica>(
      environment.apiUrlAuth, 
      this.api, 
      `actualizar/${id}`, 
      formula
    );
  }

  /**
   * Inactiva una fórmula médica (soft delete).
   * @param id Identificador de la fórmula
   * @returns Observable con la respuesta del servidor
   */
  deleteFormula(id: number): Observable<any> {
    return this.backendService.delete<any>(
      environment.apiUrlAuth, 
      this.api, 
      `eliminar/${id}`
    );
  }
}